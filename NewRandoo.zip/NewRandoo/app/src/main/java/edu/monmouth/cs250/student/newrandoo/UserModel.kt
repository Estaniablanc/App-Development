package edu.monmouth.cs250.student.newrandoo

import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class UserModel {
    private lateinit var dbReference: DatabaseReference

    fun addUser(uid: String, uName: String) {
        dbReference = Firebase.database.reference
        dbReference.child("Users").child(uid).setValue(uName)
    }

    fun getUserName (uid: String) {
        var data: String? = null
        dbReference = Firebase.database.reference
        dbReference.child("Users").child(uid).get().addOnSuccessListener {
            data = it.value as String
            User.initUserInfo(uid, data!!)
        }.addOnFailureListener{

        }

    }
}