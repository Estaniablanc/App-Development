package edu.monmouth.cs250.student.newrandoo

import android.content.Context
import android.os.Parcelable

import kotlinx.parcelize.Parcelize
import org.json.JSONArray
import org.json.JSONException
import java.io.IOException

@Parcelize

class Restaurant ( val name: String, val town: String, val lat: Double, val long: Double, val zip: Int): Parcelable {

    companion object {
        private var totalRestaurant = mutableListOf<Restaurant>()

        fun getAllRestaurants(): MutableList<Restaurant> {
            return totalRestaurant
        }

        fun getRestaurantsFromFile( filename: String,  context: Context): MutableList<Restaurant> {
            val restaurants = mutableListOf<Restaurant>()

            try {
                // Load data
                val jsonString = loadJsonFromAsset(filename, context)
                if (jsonString != null) {
                    // val json = JSONObject(jsonString)  // decode JSON Sting to an key-value pair map

                    val restaurantsJSONarray = JSONArray(jsonString)

                    // Get restaurant objects from data
                    (0 until restaurantsJSONarray.length()).mapTo(restaurants) {
                        Restaurant(
                            restaurantsJSONarray.getJSONObject(it).getString("NAME"),
                            restaurantsJSONarray.getJSONObject(it).getString("TOWN"),
                            restaurantsJSONarray.getJSONObject(it).getDouble("LATITUDE"),
                            restaurantsJSONarray.getJSONObject(it).getDouble("LONGITUDE"),
                            restaurantsJSONarray.getJSONObject(it).getInt("ZIP_CODE"),
                        )
                    }

                } else {
                    println("not a valid JSON string")
                }


            } catch (e: JSONException) {
                e.printStackTrace()
            }

            if (totalRestaurant.isEmpty()) {
                totalRestaurant = restaurants
            }
            return restaurants
        }

        // open file and read all characters into a buffer. Convert buffer to String

        private fun loadJsonFromAsset(filename: String, context: Context): String? {
            var json: String?


            try {
                val inputStream = context.assets.open(filename)
                val size = inputStream.available()
                val buffer = ByteArray(size)

                inputStream.read(buffer)
                inputStream.close()
                val charset = Charsets.UTF_8

                json = buffer.toString(charset)


            } catch (ex: IOException) {
                ex.printStackTrace()
                return null
            }

            return json
        }
    }
}