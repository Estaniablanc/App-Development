package edu.monmouth.cs250.student.newrandoo

object User {
    var userID: String = ""
    var userName: String = ""

    fun initUserInfo (uid: String, uName: String)  {
        this.userID = uid
        this.userName = uName
    }

    fun getUserInfo (): String {
        return userName
    }

}